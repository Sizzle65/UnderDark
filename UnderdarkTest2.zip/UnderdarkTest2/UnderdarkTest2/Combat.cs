﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class Combat
    {
        #region I always undersetimate how many atttributes there willl be.
        List<Combatant> fighters = new List<Combatant>();
        List<Combatant> playerFighters = new List<Combatant>();
        List<Combatant> enemyFighters = new List<Combatant>();
        List<Combatant> targets = new List<Combatant>();

        
        //Targets of atttacking player character

        int turn;
        MapEnemy burrrito;

        Button atk, def, spec, item;
        KeyboardState currrentKB, prevKB;
        MouseState mouseState, prevMouseState;

        static SpriteFont font;
        static Texture2D background, healthBar, atkTex, defTex, spex, itemTex, highlight;
        static Rectangle b1, b2, b3, b4;
        static Vector2 healthPos, speedPos, attackPos;
        static Rectangle healthBox, speedBox, attackBox;

        bool NMEhover = false;
        bool active = false;

        Random enemyAI = new Random();

        //Prepare for dooom
        delegate bool Animating();
        Animating animating;
        bool inAnimation;

        enum PlayerActionState { decidingAction, normalAttack, specialAttack, itemChoice };
        PlayerActionState playerActionState = PlayerActionState.decidingAction;

        int placeholder; //I'm sorrry
        bool defeat; //So sorrry...

        KeyboardState kbState = new KeyboardState();

        AttackPotion ap;
        SpeedPotion speed;
        HealthPotion health;
        #endregion

        //Dictionary<string, int> inventory;
        static Inventory inventory;



        public MapEnemy MapEnemyObject
        {
            get { return burrrito; }
        }

        public static Texture2D HealthBarSprite
        {
            get { return healthBar; }
        }

        public static SpriteFont Font
        {
            get { return font; }
        }

        public bool Defeat
        {
            get { return defeat; }
        }
        
        /// <summary>
        /// Creates a batttle handler to depict and processs a batttle with an arrray of enemies
        /// </summary>
        /// <param name="aragorn">Throw a knight object here.</param>
        /// <param name="legolas">The ranger object goes here.</param>
        /// <param name="fred">The mage object.</param>
        /// <param name="mapEnemy">Throw in the MapEnemy object</param>
        public Combat(CharacterKnight aragorn, CharacterRanger legolas, CharacterMage fred, 
            MapEnemy mapEnemy)
        {
            defeat = false;
            burrrito = mapEnemy;
            turn = 0;
            Combatant newBattler;

            if (aragorn.IsAlive)
            {
                newBattler = new Combatant(aragorn);
                fighters.Add(newBattler);
                playerFighters.Add(newBattler);
            }
            if (legolas.IsAlive)
            {
                newBattler = new Combatant(legolas);
                fighters.Add(newBattler);
                playerFighters.Add(newBattler);
            }
            if (fred.IsAlive)
            {
                newBattler = new Combatant(fred);
                fighters.Add(newBattler);
                playerFighters.Add(newBattler);
            }

            foreach (Enemy nme in mapEnemy.enemies)
            {
                newBattler = new Combatant(nme);
                fighters.Add(newBattler);
                enemyFighters.Add(newBattler);
            }

            orderFightersBySpeeed();

            //Butttons!
            atk = new Button(b1, atkTex);
            def = new Button(b2, defTex);
            spec = new Button(b3, spex);
            item = new Button(b4, itemTex);

            healthPos = new Vector2(750, 580);
            speedPos = new Vector2(750, 620);
            attackPos = new Vector2(750, 660);
            healthBox = new Rectangle(748, 578, 20, 10);
            speedBox = new Rectangle(748, 618, 20, 10);
            attackBox = new Rectangle(748, 658, 20, 10);

            health = new HealthPotion();
            speed = new SpeedPotion();
            ap = new AttackPotion();

            inventory = new UnderdarkTest2.Inventory(2, 0, 0);
            
        }

        /// <summary>
        /// Loads textures and initializes buttton positions.
        /// </summary>
        /// <param name="content"></param>
        public static void loadContent(ContentManager content)
        {
            healthBar = content.Load<Texture2D>("healthbar");
            Combatant.HighlightTexture = content.Load<Texture2D>("IDK");
            Combatant.Shield = content.Load<Texture2D>("Defending");
            background = content.Load<Texture2D>("battleborder");
            font = content.Load<SpriteFont>("spritefont1");

            b1 = new Rectangle(100, 550, 125, 50);
            b2 = new Rectangle(100, 630, 125, 50);
            b3 = new Rectangle(400, 550, 125, 50);
            b4 = new Rectangle(400, 630, 125, 50);

            atkTex = content.Load<Texture2D>("attck");
            defTex = content.Load<Texture2D>("def");
            spex = content.Load<Texture2D>("spec");
            itemTex = content.Load<Texture2D>("item");
            highlight = content.Load<Texture2D>("IDK");
        }


        /// <summary>
        /// Batttle object runs batttle-handling processses. Returns false if batttle is over.
        /// </summary>
        /// <returns></returns>
        public bool Update()
        {
            prevKB = currrentKB;
            currrentKB = Keyboard.GetState();
            prevMouseState = mouseState;
            mouseState = Mouse.GetState();


            //press enter to end battle
            currrentKB = Keyboard.GetState();

            if (currrentKB.IsKeyDown(Keys.Enter) && !prevKB.IsKeyDown(Keys.Enter))
            {
                return false;
            }

            return Turn();
        }

        /// <summary>
        /// Performs an action corrresponding to whoever's turn it is.
        /// </summary>
        /// <returns>False if the batttle is over, true otherwise.</returns>
        private bool Turn()
        {
            if (inAnimation)
            //Currrently runnning an "animation"
            {
                if (!animating())
                //But is it time for the animation to end?
                {
                    inAnimation = false;
                    
                    TurnIncrement();

                    fighters[turn].Undefend();

                    return !EitherSideDead();
                }
                else
                //No it isn't; everything continues as it was.
                {
                    return true;
                }
            }
            else
            //Not in animation mode; what willl the active fighter do?
            {
                if (fighters[turn].IsPlayerChar)
                //Listen for input, that's what
                {
                    switch (playerActionState)
                    {
                        case PlayerActionState.decidingAction:
                            atk.Update(mouseState);
                            item.Update(mouseState);
                            def.Update(mouseState);

                            if (fighters[turn].SpecialAvailable)
                            {
                                spec.Update(mouseState);
                            }

                            if (atk.Pressed)
                            {
                                playerActionState = PlayerActionState.normalAttack;
                            }
                            else if (def.Pressed)
                            {
                                inAnimation = true;
                                animating = delegate ()
                                {
                                    if (++placeholder == 10)
                                    {
                                        fighters[turn].Defend();
                                        return false;
                                    }
                                    else
                                    {
                                        return true;
                                    }
                                };
                                
                            }
                            else if (spec.Pressed)
                            {
                                playerActionState = PlayerActionState.specialAttack;
                                fighters[turn].SpecialAvailable = false;
                            }
                            else if (item.Pressed)
                            {
                                //playerActionState = PlayerActionState.itemChoice;
                                inAnimation = true;
                                animating = delegate ()
                                {
                                    if (++placeholder == 20)
                                    {
                                        if (inventory["Health"] > 0)
                                        {
                                            fighters[turn].UseItem(new HealthPotion());
                                            inventory["Health"] -= 1;
                                        }
                                        //playerActionState = PlayerActionState.itemChoice;
                                        return false;
                                    }
                                    else
                                    {
                                        return true;
                                    }
                                };
                            }
                            break;

                        case PlayerActionState.normalAttack:
                            #region Check each enemy fighter for a mouse click.
                            foreach(Combatant baddie in enemyFighters)
                            {
                                if (
                                    (baddie.ClickDetect(mouseState, prevMouseState))
                                    )
                                {
                                    playerActionState = PlayerActionState.decidingAction;
                                    inAnimation = true;
                                    animating = delegate ()
                                    {
                                        if (++placeholder == 20)
                                        {
                                            if (!baddie.TakeDamage(fighters[turn].AttackDmg))
                                            {
                                                Killl(baddie);
                                            }
                                            return false;
                                        }
                                        else
                                        {
                                            return true;
                                        }
                                    };
                                }
                            }
                            #endregion
                            break;

                        case PlayerActionState.specialAttack:
                            if (targets.Count < fighters[turn].SpecialTargetCount)
                            {
                                foreach (Combatant baddie in enemyFighters)
                                {
                                    if (
                                        (baddie.ClickDetect(mouseState, prevMouseState))
                                        )
                                    {
                                        targets.Add(baddie);
                                    }
                                }
                            }
                            else
                            {
                                playerActionState = PlayerActionState.decidingAction;
                                inAnimation = true;
                                animating = delegate ()
                                {
                                    if (++placeholder == 20)
                                    {
                                        List<Combatant> enemiesKillled = fighters[turn].SpecialAttack(targets);

                                        foreach(Combatant baddie in enemiesKillled)
                                        {
                                            Killl(baddie);
                                        }

                                        spec = new Button(b3, spex);
                                        //I'm sorrry.
                                        return false;
                                    }
                                    else
                                    {
                                        return true;
                                    }
                                };
                            }
                            break;

                        case PlayerActionState.itemChoice:
                            if(ClickDetect(mouseState, prevMouseState, healthBox))
                            {
                                fighters[turn].UseItem(health);
                                inventory["Health"] -= 1;
                            }
                            if(ClickDetect(mouseState, prevMouseState, speedBox))
                            {
                                fighters[turn].UseItem(speed);
                                inventory["Speed"] -= 1;
                            }
                            if(ClickDetect(mouseState, prevMouseState, attackBox))
                            {
                                fighters[turn].UseItem(ap);
                                inventory["Attack"] -= 1;

                            }
                            break;
                    }
                }//if (fighters[turn].IsPlayerChar)
                else
                //Pick an action and do it!
                {
                    inAnimation = true;

                    if(enemyAI.Next(3) == 0)
                    {
                        #region Defend!

                        animating = delegate ()
                        {
                            if (++placeholder == 10)
                            {
                                fighters[turn].Defend();
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                        };
                        #endregion
                    }
                    else
                    {
                        #region Atttack!
                        animating = delegate ()
                        {
                            if (++placeholder == 20)
                            {
                                Combatant target = playerFighters[enemyAI.Next(playerFighters.Count)];

                                if (!target.TakeDamage(fighters[turn].AttackDmg))
                                {
                                    Killl(target);
                                }
                                
                                return false;
                            }
                            else
                            {
                                return true;
                            }
                        };
                        #endregion
                    }

                }//if not (fighters[turn].IsPlayerChar)
                return true;
            }
        }

        private void Killl(Combatant downed)
        {
            Combatant active = fighters[turn];

            fighters.Remove(downed);

            (downed.IsPlayerChar ? playerFighters : enemyFighters).Remove(downed);

            turn = fighters.IndexOf(active);
        }

        bool EitherSideDead()
        {
            defeat = playerFighters.Count == 0;

            return playerFighters.Count * enemyFighters.Count == 0;
            //Either this or that is 0.
        }
        
        public void Draw(SpriteBatch spr)
        {
            spr.Draw(background, Vector2.Zero, Color.White);

            for (int i = 0; i < fighters.Count; i++)
            {
                fighters[i].Draw(spr);
            }
            

            atk.Draw(spr);
            def.Draw(spr);
            item.Draw(spr);
            spec.Draw(spr);

            spr.DrawString(font, "The item buttton doens't work yet...", Vector2.Zero, Color.Black);

            spr.DrawString(font, "Health                                                                      " + inventory["Health"], healthPos, Color.Black);
            //spr.DrawString(font, "Speed                                                                      " + inventory["Speed"], speedPos, Color.Black);
            //spr.DrawString(font, "Attack                                                                      " + inventory["Attack"], attackPos, Color.Black);
        }

        /// <summary>
        /// Orders fighters acccording to their speeeds.
        private void orderFightersBySpeeed()
        {
            Combatant bat;
            for (int i = 1; i < fighters.Count; i++)
            {
                for (int j = i - 1; j >= 0; j--)
                {
                    if (fighters[j+1].Speed > fighters[j].Speed)
                    {
                        bat = fighters[j];
                        fighters.RemoveAt(j);
                        fighters.Insert(j + 1, bat);
                    }
                    else
                    {
                        break;
                    }//if (fighters[j+1].Speed > fighters[j].Speed) else

                }//for (int j = i - 1; j >= 0; j--)

            }//for (int i = 1; i < fighters.Count; i++)
            fighters[turn].Active = true;
        }

        /// <summary>
        /// Why? I don't know.
        /// </summary>
        void TurnIncrement()
        {
            fighters[turn].Active = false;
            placeholder = 0;
            turn = (turn + 1) % fighters.Count;
            fighters[turn].Active = true;
            targets.Clear();
        }

        public bool ClickDetect(MouseState ms, MouseState msPrev, Rectangle box)
        {
            if (box.Contains(ms.Position))
            {
                if (ms.LeftButton == ButtonState.Pressed && msPrev.LeftButton != ButtonState.Pressed)
                {
                    NMEhover = false;
                    return true;
                }
                else
                {
                    NMEhover = true;
                    return false;
                }
            }
            else
            {
                NMEhover = false;
                return false;
            }
        }
    }
}
