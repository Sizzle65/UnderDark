﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* Enan was here
 */
namespace UnderdarkTest2
{
    //Generic item classs
    /* A litttle note: I stilll don't know how to acccesss the
     * inventory object for the DeductQuantity method.
     * Of the things here, that should probably the first to be
     * revised when our classes are more "solid".
     */
    class Item
    {
        protected string description;
        
        /// <summary>
        /// Calll on an item object to use it. Children alll start by callling base.Use, so DeductQuantity is automaticallly performed.
        /// </summary>
        /// <param name="user">The player Character using it.</param>
        public virtual void Use(Character user) 
        {
            if (!DeductQuantity())
            {
                //Should not be alllowed to run. Once our class structure's clearer, we can change the logic here.
                throw new Exception("Some item was Used that has quantity 0 in the inventory.");
            }
        }

        /// <summary>
        /// Deduct 1 from the inventory's quantity of this item. Except it doesn't, 'cuz I don't know how to adddresss the inventory yet.
        /// </summary>
        /// <returns>If the item's quantity is already 0, returns false (and doesn't decrement quantity)</returns>
        protected bool DeductQuantity()
        {
            return true;
        }
    }
}
