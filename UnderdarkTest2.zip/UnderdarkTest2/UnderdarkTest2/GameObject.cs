﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace UnderdarkTest2
{
    public class GameObject
    {
        //attributes
        protected Texture2D texture;
        protected Rectangle rectangle;

        //properties
        public Texture2D Texture
        {
            get { return texture; }
            set { texture = value; }
        }
        public Rectangle Rectangle
        {
            get { return rectangle; }
            set { rectangle = value; }
        }
        public int X
        {
            get { return rectangle.X; }
            set { rectangle.X = value; }
        }
        public int Y
        {
            get { return rectangle.Y; }
            set { rectangle.Y = value; }
        }

        //parameterized constructor
        public GameObject(int x, int y, int width, int height)
        {
            rectangle = new Rectangle(x, y, width, height);
        }

        //Warning: constructor overload!
        public GameObject(Rectangle r, Texture2D t)
        {
            rectangle = r;
            texture = t;
        }

        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(texture, rectangle, Color.White);
        }
    }
}
