﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class CharacterRanger : Character
    {
        public CharacterRanger(string nm, int x, int y) : base(nm, "Ranger", 60, 5, 26, x, y, 2)
        {

        }

        /// <summary>
        /// Ranger neeeds two combatants
        /// </summary>
        /// <param name="targets"></param>
        public override List<Combatant> SpecialAttack(List<Combatant> targets)
        {
            /* This is beyond adorable.
            int att1 = Attack();
            int att2 = Attack();

            return att1 + att2;
            */


            List<Combatant> result = new List<Combatant>();
            foreach (Combatant baddie in targets)
            {
                if (!baddie.TakeDamage((int)(attackDmg * 0.7)))
                {
                    result.Add(baddie);
                }
            }
            return result;
        }
    }
}
