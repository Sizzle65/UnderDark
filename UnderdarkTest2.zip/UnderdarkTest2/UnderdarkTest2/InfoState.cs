﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Input;
using System.IO;

namespace UnderdarkTest2
{
    class InfoState
    {
        Button back;
        Rectangle bRect;
        Texture2D bT;
        MouseState mouseState = new MouseState();
        MouseState prevState = new MouseState();
        List<string> info = new List<string>();
        SpriteFont sf;
        Vector2 textPos;
        bool placed;

        public InfoState()
        {
            //read in text, print it out, wrap it or something, I don't know
            StreamReader sr = new StreamReader("..\\..\\..\\..\\..\\..\\description.txt");
            string line = "";

            while (true)
            {
                
                line = sr.ReadLine();
                if(line == null)
                {
                    break;
                }
                    info.Add(line);
                
            }
            sr.Close();
            
        }

        public void loadContent(ContentManager content)
        {
            bT = content.Load<Texture2D>("back");
            bRect = new Rectangle((1280 / 2) - (250 / 2), ((720 / 2) + 300) - (50), 250, 75);
            back = new Button(bRect, bT);
            sf = content.Load<SpriteFont>("SpriteFont1");
            textPos = new Vector2(15,25);
            placed = false;
        }

        public void Draw(SpriteBatch sp)
        {
            sp.Draw(back.Texture, back.Rectangle, Color.White);
            
            foreach(string s in info)
            {
                sp.DrawString(sf, s, textPos, Color.Black);
                if(textPos.Y > 570)
                {
                    textPos.X = 675;
                    textPos.Y = 0;
                }
                textPos.Y += 25;
                
            }
            textPos.Y = 25;
            textPos.X = 15;
        }

        public void Update()
        {
            prevState = mouseState;
            mouseState = Mouse.GetState();
            back.Update(mouseState,prevState);
        }

        public bool Exit
        {
            get { return back.Pressed; }
        }

    }
}
