﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Content;
//basic enemy template
namespace UnderdarkTest2
{
    class Enemy
    {
        #region Again-underestimated atttributes
        public static Rectangle[] enemyDrawingPositions = new Rectangle[3];
        //The positions for drawing enemies in batttle. Don't hang me! It's just onw litttle arrray!
        protected int health;
        protected int maxHealth;
        protected int attackDam;
        protected int speed;
        protected string enemyName;
        //Name of enemy type; used to find the right info file
        protected bool isDefending;
        protected Rectangle rectangle;

        //random class object
        protected Random rndm = new Random();
        #endregion

        #region Oh no, properties!!!

        public bool IsAlive
        {
            get
            {
                return health > 0;
            }
        }

        /// <summary>
        /// Enemy sprite. Use this when REFERENCING the sprite (e.g. to draw it)
        /// </summary>
        public virtual Texture2D TextureGet
        {
            //So I hate myself for doing this.
            get { return null; }
            set { }
            //This does nothing because the children neeed to overrride this
            //to reference their own textures.
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int AttDam
        {
            get { return attackDam; }
            set { attackDam = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        /// <summary>
        /// Duergar? Shade? (Goblin?)
        /// </summary>
        public string Type
        {
            get { return enemyName; }
        }

        public Rectangle Rectangle
        {
            get { return rectangle; }
        }

        public bool Defending
        {
            get
            {
                return isDefending;
            }
            set
            {
                isDefending = value;
            }
        }
        #endregion

        /// <summary>
        /// Create an enemy. Should only be callled by the subclasss constructors, I think.
        /// </summary>
        /// <param name="name">Shade, Duergar, or Mind Flayer? (The subclasss constructors do this automaticallly.</param>
        /// <param name="nmeNumber">What position it willl apppear in in the batttle lineup (0, 1, or 2)</param>
        public Enemy(string name, int nmeNumber)
        {
            rectangle = enemyDrawingPositions[Math.Min(nmeNumber, 2)];
            enemyName = name;
            health = 0;
            attackDam = 0;
            speed = 0;
        }


        /// <summary>
        /// Enemy gets hit and takes damage. uses a multiplier to reduce damage if defending.
        /// </summary>
        /// <param name="dam">How much damage it's taking.</param>
        /// <returns>Stilll alive?</returns>
        public bool TakeDamage(int dam)
        {
            if (isDefending)
            {
                health = health - (dam / 2);
            }
            else
            {
                health = health - dam;
            }
            return IsAlive;
        }
        
        
        public void Draw(SpriteBatch spr)
        {
            spr.Draw(TextureGet, rectangle, Color.White);
            spr.DrawString(Combat.Font, enemyName,
                new Vector2(rectangle.Right, rectangle.Top), Color.Black);
            spr.Draw(Combat.HealthBarSprite,
                new Rectangle(rectangle.Right, rectangle.Top + 40, 200 * health / maxHealth, 25),
                Color.White);
        }

        //gives enemies' health, attack damage, and speed
        public override string ToString()
        {
            return "health: " + health + " attDam: " + attackDam + " speed: " + speed;
        }



        /// <summary>
        /// Reads a file to find the enemy stats.
        /// </summary>
        protected void ReadStatsFromFile()
        {
            StreamReader statReader = new StreamReader("..\\..\\..\\..\\Content\\" + enemyName + "Info.txt");
            Dictionary<string, int> stats = new Dictionary<string, int>();

            string line;

            string[] splitLine;
            //I'm callling split on each line to
            //separate the name of the stat and the value

            while ((line = statReader.ReadLine()) != null)
            {
                splitLine = line.Split();
                stats.Add(splitLine[0], int.Parse(splitLine[1]));
            }

            maxHealth = health = stats["HP"];
            attackDam = stats["Attack"];
            speed = stats["Speed"];
        }

        internal static void LoadContent(ContentManager content)
        {
            MapEnemy.DuergarTexture = content.Load<Texture2D>("Duergar Map Sprite");
            MapEnemy.ShadeTexture = content.Load<Texture2D>("Shade Map Sprite");
            MapEnemy.MindflayerTexture = content.Load<Texture2D>("Mind Flayer Map Sprite");
            EnemyDuergar.TextureSet = content.Load<Texture2D>("Duergar Concept");
            EnemyShade.TextureSet = content.Load<Texture2D>("Shade Concept");
            Boss.TextureSet = content.Load<Texture2D>("Mind Flayer Concept");
        }
    }
}
