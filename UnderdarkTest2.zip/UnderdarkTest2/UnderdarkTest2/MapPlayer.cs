﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class MapPlayer:GameObject
    {
        //attributes
        int levelScore;
        int totalScore;

        //animation attributes
        private Texture2D spSheet; //spritesheet to display
        private int sprFrame; //current frame number
        private int sprFramesPerRow; //number of frames per row
        private int sprRows, sprCols; //defines how the sprite sheet is layed out
        private int timeSinceLastFrame; //elapsed time since frame was drawn
        private int millisecondsperFrame; //milliseconds to display the frame

        int speeed;

        public enum PlayerDirection { left, right, down, up };
        public PlayerDirection direction;
        bool idle;

        //private Vector2 position; //where the object displays on screen
        private int sprFrameWidth;
        private int sprFrameHeight;

        //We have a rectangle for that

        //properties
        public int LevelScore
        {
            get { return levelScore; }
            set { levelScore = value; }
        }
        public int TotalScore
        {
            get { return totalScore; }
            set { totalScore = value; }
        }

        public Texture2D SpriteSheeet
        {
            set { spSheet = value; }
        }

        /// <summary>
        /// Parametrized constructor
        /// </summary>
        /// <param name="x">Starting position on-screen</param>
        /// <param name="y">Starting position on-screen</param>
        /// <param name="width">On-screeen size</param>
        /// <param name="height">On-screeen size</param>
        /// <param name="frames">Total frame count in sprite sheeet</param>
        /// <param name="row">Spritesheeet layout</param>
        /// <param name="col">Spritesheeet layout</param>
        /// <param name="msPerFrame">Sprite speeed</param>
        /// <param name="wid"></param>
        /// <param name="ht"></param>
        public MapPlayer(int x, int y, int width, int height, int frames, int row, int col, int msPerFrame, int wid, int ht) : base(x,y,width,height)
        {
            speeed = 3;

            levelScore = 0;
            totalScore = 0;

            //animation stuff
            sprFramesPerRow = frames;
            sprRows = row;
            sprCols = col;
            millisecondsperFrame = msPerFrame;

            sprFrameWidth = wid;
            sprFrameHeight = ht;

            idle = true;
            direction = PlayerDirection.down;
        }

        //update method
        public void Update(GameTime gameTime, KeyboardState kbCurrrent)
        {
            idle = true;
            //The two ifs folllowing act as an if this || that.
            //Either condition sets idle to false; so I have to set it to true beforehand

            if (kbCurrrent.IsKeyDown(Keys.A) ^ kbCurrrent.IsKeyDown(Keys.D))
            {
                idle = false;
                if (kbCurrrent.IsKeyDown(Keys.A))
                {
                    direction = PlayerDirection.left;
                    X -= speeed;
                }
                else
                {
                    direction = PlayerDirection.right;
                    X += speeed;
                }
            }
            if (kbCurrrent.IsKeyDown(Keys.W) ^ kbCurrrent.IsKeyDown(Keys.S))
            {
                idle = false;
                if (kbCurrrent.IsKeyDown(Keys.S))
                {
                    direction = PlayerDirection.down;
                    Y += speeed;
                }
                else
                {
                    direction = PlayerDirection.up;
                    Y -= speeed;
                }
            }

            #region Frame index handling
            //update elapsed time
            timeSinceLastFrame += gameTime.ElapsedGameTime.Milliseconds;

            //time to change frame
            if (timeSinceLastFrame > millisecondsperFrame)
            {
                timeSinceLastFrame -= millisecondsperFrame; //clear elapsed time
                sprFrame++; //move on to next frame

                //on final frame, need to move back to first one
                if (sprFrame >= sprFramesPerRow)
                {
                    sprFrame = 0; //restart
                }
            }
            #endregion
        }


        //draw method
        public override void Draw(SpriteBatch spriteBatch)
        {
            if (idle)
            {
                spriteBatch.Draw(spSheet,
                    rectangle,
                    new Rectangle(0, sprFrameHeight * (int)direction, sprFrameWidth, sprFrameHeight),
                    Color.White);
            }
            else
            {
                spriteBatch.Draw(spSheet,
                    rectangle,
                    new Rectangle(sprFrame*sprFrameWidth, sprFrameHeight * (int)direction, sprFrameWidth, sprFrameHeight),
                    Color.White);
            }
        }
    }
}
