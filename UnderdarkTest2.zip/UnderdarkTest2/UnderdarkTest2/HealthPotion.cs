﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class HealthPotion : Item
    {
        //Tentative heal amount. Fix!
        const int HEAL_AMT = 15;
        
        /// <summary>
        /// HealthPotion.Use heals the user by some amount, tentatively set to 15
        /// </summary>
        /// <param name="user">The Character that's using the potion</param>
        public override void Use(Character user)
        {
            base.Use(user);
            user.Health += HEAL_AMT;

            if(user.Health > user.MaxHealth)
            {
                user.Health = user.MaxHealth;
            }
        }
    }
}
