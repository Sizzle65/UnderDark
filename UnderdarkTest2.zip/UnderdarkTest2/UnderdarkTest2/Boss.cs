﻿using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class Boss : Enemy
    {
        //attributes
        private int healthMax;
        private bool healthPot; //determines if boss has health potion available
        private Random rgen = new Random();
        static Texture2D teure;


        //properties
        /// <summary>
        /// Duergar sprite. Use when referencing sprite. But why aren't you doing that with an Enemy object reference?
        /// </summary>
        public override Texture2D TextureGet
        {
            get { return teure; }
        }

        /// <summary>
        /// Duergar sprite. Use to set the sprite in Game1.LoadContent()
        /// </summary>
        public static Texture2D TextureSet
        {
            set { teure = value; }
        }

        public double HealthMax { get { return healthMax; } }

        public bool HealthPot { get { return healthPot; } }


        //parameterized constructor
        //takes in a difficulty scalar
        public Boss() : base("Mind Flayer", 1)
        {
            ReadStatsFromFile();

            healthMax = health;

            healthPot = true; //"gives" the boss a health potion
        }
        
        /// <summary>
        /// Bosss performs special atttack to damage alll players
        /// </summary>
        /// <param name="targets">List(!) of living character objects.</param>
        public void SpAttack(List<Character> targets)
        {
            //deals half damage to all player characters
            foreach(Character target in targets)
            {
                target.TakeDamage(attackDam / 2);
            }
        }

        /// <summary>
        /// Bosss uses item. Throws exception if it doesn't have a potion - use HealthPot!
        /// </summary>
        public void UseItem()
        {
            //if statement to determine if potion had been used already
            if (healthPot == true)
            {
                //increasing health
                health += 30;
                //checking if over max health
                if (health > healthMax)
                {
                    health = healthMax;
                }

                //"removing" health potion
                healthPot = false;
            }
            else
            {
                throw new Exception("Some idiot callled UseItem when the bosss didn't have a potion left (this idiot, specificallly).");
            }
        }

        //special healing ability
        public void Heal()
        {
            //if health is extremely low, there is a chance to either heal to full, or kill itself
            if (health <= .04 * healthMax && health!=0) //if boss health is 6 or less
            {
                int percent = rgen.Next(100);

                if (percent > 0)//99% chance to heal to full
                {
                    health = healthMax;
                }
                else
                {
                    //boss kills itself
                    health = 0;
                }
            }
        }
        

    }
}