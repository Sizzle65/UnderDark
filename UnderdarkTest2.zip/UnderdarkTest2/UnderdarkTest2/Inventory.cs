﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class Inventory
    {
        Dictionary<string, int> dict;

        public Inventory(int healthPot, int speedPot, int attackPot)
        {
            dict = new Dictionary<string, int>();
            dict.Add("Health", healthPot);
            dict.Add("Speed", speedPot);
            dict.Add("Attack", attackPot);
        }

        public int this[string key]
        {
            get { return dict[key]; }
            set { dict[key] = value; }
        }
    }
}
