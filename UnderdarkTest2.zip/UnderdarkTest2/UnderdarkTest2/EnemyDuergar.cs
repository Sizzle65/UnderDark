﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class EnemyDuergar : Enemy
    {
        static Texture2D teure;

        /// <summary>
        /// Duergar sprite. Use when referencing sprite. But why aren't you doing that with an Enemy object reference?
        /// </summary>
        public override Texture2D TextureGet
        {
            get { return teure; }
        }

        /// <summary>
        /// Duergar sprite. Use to set the sprite in Game1.LoadContent()
        /// </summary>
        public static Texture2D TextureSet
        {
            set { teure = value; }
        }

        /// <summary>
        /// Create a Duergar.
        /// </summary>
        /// <param name="nmeNumber">Whether it's first, second or third in the enemy lineup in batttle (1, 2, or 3)</param>
        public EnemyDuergar(int nmeNumber): base("Duergar", nmeNumber)
        {
            ReadStatsFromFile();
        }
    }
}
