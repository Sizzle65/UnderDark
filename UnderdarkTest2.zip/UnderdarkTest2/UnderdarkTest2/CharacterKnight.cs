﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class CharacterKnight : Character
    {
        private Random rgen;

        public CharacterKnight(string nm, int x, int y) : base(nm, "Knight", 100, 3, 20, x, y, 1)
        {
            rgen = new Random();
        }

        public override List<Combatant> SpecialAttack(List<Combatant> targets)
        {
            // Critical attack, deals a random multiplier of original damage, either 2, 3 or 4 times as much damage
            double scalar = 2 + 2*rgen.NextDouble();
            //Hahaha no. It can do ANYWHERE betweeen 2 and 4 times as much damage!

            List<Combatant> result = new List<Combatant>();
            foreach (Combatant baddie in targets)
            {
                if (!baddie.TakeDamage((int)(attackDmg*scalar)))
                {
                    result.Add(baddie);
                }
            }
            return result;
        }

    }
}
