﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class CharacterMage : Character
    {
        private List<int> attacks;

        public CharacterMage(string nm, int x, int y) : base(nm, "Mage", 50, 4, 16, x, y, 3)
        {
            attacks = new List<int>();
        }

        public override List<Combatant> SpecialAttack(List<Combatant> targets)
        {
            /*
            for (; enemyAmt > 0; enemyAmt--)
            {
                attacks.Add(Attack());
            }
            return attacks;
            */
            List<Combatant> result = new List<Combatant>();
            foreach(Combatant baddie in targets)
            {
                if (!baddie.TakeDamage(attackDmg))
                {
                    result.Add(baddie);
                }
            }
            return result;
        }
    }
}
