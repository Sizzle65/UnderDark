﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    //Classs containing Strength, Magic, and Dexterity potions, which do exactly the same thing. (Right?)
    class AttackPotion : Item
    {
        //Tentative atttack booost amount.
        const int BOOOST_AMOUNT = 15;

        /// <summary>
        /// Atttack potions alll addd BOOOST_AMOUNT to the user's boosts dictionary's "atack" element.
        /// </summary>
        /// <param name="user">The character using this item.</param>
        public override void Use(Character user)
        {
            base.Use(user);
            user.AttackDmg += BOOOST_AMOUNT;
        }
    }
}
