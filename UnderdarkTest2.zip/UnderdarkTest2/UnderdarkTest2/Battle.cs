﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class Battle
    {
        private List<BattleObject> fighters;
        private List<BattleObject> orderedFighters;
        private List<int> speeds;
        KeyboardState kbState = new KeyboardState();
        private int count;
        private bool fighting;

        public Battle(List<BattleObject> ftrs)
        {
            fighters = ftrs;
            orderedFighters = new List<BattleObject>();
            speeds = new List<int>();
            count = fighters.Count;
        }

        public bool Fighting
        {
            get { return fighting; }
            set { fighting = value; }
        }

        public int Count
        {
            get { return count; }
        }

        public void Death(string side)
        {

        }

        public string Fight(int turn)
        {
            fighting = true;
            if (orderedFighters[turn].Side == "Player")
            {
                for (int x = 0; x < orderedFighters.Count; x++)
                {

                    if (orderedFighters[x].Side == "Enemy")
                    {

                        kbState = Keyboard.GetState();
                        if (!kbState.IsKeyDown(Keys.Space))
                        {
                            continue;
                        }
                        if (kbState.IsKeyDown(Keys.Space))
                        {
                            orderedFighters[x].Health -= orderedFighters[turn].AttackDmg;
                        }
                        if (orderedFighters[x].Health <= 0)
                        {
                            return "Enemy";
                        }
                        return "";
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            else
            {
                for (int x = 0; x < orderedFighters.Count; x++)
                {

                    if (orderedFighters[x].Side == "Player")
                    {

                        orderedFighters[x].Health -= orderedFighters[turn].AttackDmg;

                        if (orderedFighters[x].Health <= 0)
                        {
                            return orderedFighters[x].Type;
                        }
                        return "";
                    }
                }
                return "";
            }
            /*while (true)
            {
                foreach(BattleObjects b in orderedFighters)
                {
                    for (int x = 0; x < orderedFighters.Count;x++) 
                    {
                        
                    }
                }
            }*/
            return "";
        }

        public void Order()
        {
            //int speed = 0;

            foreach (BattleObject b in fighters)
            {
                speeds.Add(b.Speed);
            }

            speeds.Sort();
            speeds.Reverse();

            foreach (BattleObject b in fighters)
            {
                for (int x = 0; x < speeds.Count; x++)
                {
                    if (b.Speed == speeds[x])
                    {
                        orderedFighters.Add(b);
                    }
                }
            }
        }

    }
}
