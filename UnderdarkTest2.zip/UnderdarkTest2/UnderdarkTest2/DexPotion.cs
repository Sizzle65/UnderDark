﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    //The word "dexterity" is just tooo long.
    class DexPotion : AttackPotion
    {
    }
}
