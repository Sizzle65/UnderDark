﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;

namespace UnderdarkTest2
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        #region The horrrifying list of atttributes.
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont font;

        enum GameState { Map, Combat, BossRoom, Menu, Victory, Death, Info};
        GameState gameState;
        GameState prevState;

        enum BattleState { One,Two,Boss}
        BattleState battleState;

        MapPlayer player;
        MapEnemy burrito;
        //Aaargh!
        CharacterKnight knight;
        CharacterMage mage;
        CharacterRanger ranger;
        
        Button play;
        Button settings;
        Button back;
        Button exit;
        Rectangle r;
        Rectangle rSettings;
        Rectangle b;
        Rectangle ex;
        Rectangle deathRec;
        Rectangle victoryRec;

        Combat battleHandler;
        Rectangle agroBubble;

        Vector2 V2;
        
        Rectangle coolTitle;
        Rectangle menuRec;
        //Rectangle agroBubble;
        Vector2 enemyLoc;
        Texture2D playTexture;
        
        Vector2 title;
        Vector2 deathMessage;
        Vector2 warrior;
        int healthbarWidth, healthbarGutter;

        List<Door> doors;
        Door dooorLeft;
        Door dooorTop;
        Door dooorRight;
        Door dooorBotttom;
        List<Door> activeDoors;

        Texture2D title2;

        
        Texture2D doorTexture;
        Texture2D background;
        Texture2D menuBG;
        Texture2D combatBG;
        Texture2D settingsTexture;
        Texture2D backT;
        Texture2D exitT;
        Texture2D deathT;
        Texture2D victoryT;

        InfoState infoState;

        MouseState mouseState = new MouseState();
        MouseState prevMS = new MouseState();
        KeyboardState kbPrev;
        KeyboardState kbState = new KeyboardState();

        Random rgen = new Random();

        Dictionary<Item, int> inventory;

        int roomNum;
        //Augh!

           
        #endregion


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = 1280;  // set this value to the desired width of your window
            graphics.PreferredBackBufferHeight = 720;   // set this value to the desired height of your window
            graphics.ApplyChanges();
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            #region Settting up enemyDrawingPositions
            Enemy.enemyDrawingPositions[0] = new Rectangle(
                (2 * GraphicsDevice.Viewport.Width / 3) - 100,
                (GraphicsDevice.Viewport.Height / 2) - 300,
                150, 150);

            Enemy.enemyDrawingPositions[1] = new Rectangle(
                (2 * GraphicsDevice.Viewport.Width / 3) - 100,
                (GraphicsDevice.Viewport.Height / 2) - 150,
                150, 150);

            Enemy.enemyDrawingPositions[2] = new Rectangle(
                (2 * GraphicsDevice.Viewport.Width / 3) - 100,
                (GraphicsDevice.Viewport.Height / 2),
                150, 150);
            #endregion

            #region Settting up healthbarDrawingPositions
            warrior = new Vector2(800, GraphicsDevice.Viewport.Height - 40);
            healthbarWidth = 100;
            healthbarGutter = 20;
            #endregion
            //There isn't actuallly a variable or atttribute or anything with that name.
            menuRec = new Rectangle(0, 0, 1920, 1080);
            deathRec = new Rectangle(0, 0, 1280, 720);
            victoryRec = new Rectangle(0, 0, 1280, 720);

            coolTitle = new Rectangle((GraphicsDevice.Viewport.Width / 2) - 490, (GraphicsDevice.Viewport.Height / 3) - 150,1000,500);

            player = new MapPlayer(
                GraphicsDevice.Viewport.Width / 2, 
                GraphicsDevice.Viewport.Height / 2, 
                /*
                GraphicsDevice.Viewport.Width/8,  //???
                GraphicsDevice.Viewport.Height/4,
                /*/
                170, 170,
                //*/
                4, 4, 4, 200, 580, 590);
            
            burrito = new MapEnemy(
                rgen.Next(20, GraphicsDevice.Viewport.Width - 50),
                rgen.Next(20, GraphicsDevice.Viewport.Width - 50),
                "Duergar", "Shade"
            );

            
            infoState = new InfoState();

            agroBubble = new Rectangle(0,
                0,
                GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            
            burrito.Active = false;

            knight = new CharacterKnight(
                "Aragorn",
                (GraphicsDevice.Viewport.Width / 3) - 100, 
                (GraphicsDevice.Viewport.Height / 2) - 300
            );
            ranger = new CharacterRanger(
                "Legolas", 
                (GraphicsDevice.Viewport.Width / 3) - 100, 
                (GraphicsDevice.Viewport.Height / 2) - 150
            );
            mage = new CharacterMage(
                "Gandalf", 
                (GraphicsDevice.Viewport.Width / 3) - 100, 
                (GraphicsDevice.Viewport.Height / 2)
            );

            deathMessage = new Vector2((GraphicsDevice.Viewport.Width/2)-50, GraphicsDevice.Viewport.Height/2);
            
            dooorLeft = new Door(0, GraphicsDevice.Viewport.Height / 2 - 100, 40, 200, doorTexture, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            dooorTop = new Door(GraphicsDevice.Viewport.Width / 2 - 100, 0, 200, 40, doorTexture, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            dooorRight = new Door(GraphicsDevice.Viewport.Width -40, GraphicsDevice.Viewport.Height/2 - 100, 40, 200, doorTexture, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            dooorBotttom = new Door(GraphicsDevice.Viewport.Width / 2- 100, GraphicsDevice.Viewport.Height-40, 200, 40, doorTexture, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            roomNum = 0;

            gameState = GameState.Menu;
            IsMouseVisible = true;
            
            r = new Rectangle((GraphicsDevice.Viewport.Width / 2)-(350/2), (GraphicsDevice.Viewport.Height / 2)-(50),350,100);
            rSettings = new Rectangle((GraphicsDevice.Viewport.Width / 2) - (350 / 2), ((GraphicsDevice.Viewport.Height / 2) + 150) - (50), 350, 100);
            b = new Rectangle((GraphicsDevice.Viewport.Width / 2) - (350 / 2), ((GraphicsDevice.Viewport.Height / 2) + 250) - (50), 350, 100);
            ex = new Rectangle((GraphicsDevice.Viewport.Width / 2) - 105,  ((GraphicsDevice.Viewport.Height / 2) + 250), 200, 75);

            enemyLoc = new Vector2(450,25);
            doors = new List<Door>();
            doors.Add(dooorLeft);
            doors.Add(dooorTop);
            doors.Add(dooorRight);
            doors.Add(dooorBotttom);
            activeDoors = new List<Door>();
            play = new Button(r, playTexture);

            inventory = new Dictionary<Item, int>();
            HealthPotion health = new HealthPotion();
            SpeedPotion speed = new SpeedPotion();
            AttackPotion ap = new AttackPotion();

            inventory.Add(health, 20);
            inventory.Add(speed, 20);
            inventory.Add(ap, 20);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            // TODO: use this.Content to load your game content here
            player.SpriteSheeet = Content.Load<Texture2D>("partyWalk.png");
            knight.Texture = Content.Load<Texture2D>("Warrior Concept");
            mage.Texture = Content.Load<Texture2D>("Wizard Concept");
            ranger.Texture = Content.Load<Texture2D>("Ranger Concept");
            Enemy.LoadContent(Content);
            playTexture = Content.Load<Texture2D>("button");
            font = Content.Load<SpriteFont>("SpriteFont1");
            settingsTexture = Content.Load<Texture2D>("infoButton");
            dooorLeft.Texture = Content.Load<Texture2D>("caveDoorLeft");
            dooorTop.Texture = Content.Load<Texture2D>("caveDoorTop");
            dooorRight.Texture = Content.Load<Texture2D>("caveDoorRight");
            dooorBotttom.Texture = Content.Load<Texture2D>("caveDoorBot");
            background = Content.Load<Texture2D>("stonebackground");
            combatBG = Content.Load<Texture2D>("combatBackground");
            menuBG = Content.Load<Texture2D>("menubackground");
            play = new UnderdarkTest2.Button(r, playTexture);
            settings = new Button(rSettings, settingsTexture);
            title2 = Content.Load<Texture2D>("title");
            backT = Content.Load<Texture2D>("back");
            back = new UnderdarkTest2.Button(b, backT);
            exitT = Content.Load<Texture2D>("exitButton");
            deathT = Content.Load<Texture2D>("death");
            victoryT = Content.Load<Texture2D>("win");

            exit = new Button(ex,exitT);

            Combat.loadContent(Content);
            infoState.loadContent(Content);

            doors.Add(dooorLeft);
            doors.Add(dooorTop);
            doors.Add(dooorRight);
            doors.Add(dooorBotttom);

            activeDoors.Add(dooorLeft);
            activeDoors.Add(dooorTop);
            activeDoors.Add(dooorRight);
            activeDoors.Add(dooorBotttom);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            //if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                //Exit();

            // TODO: Add your update logic here

            //testing game state switches
            
            if(gameState == GameState.Combat)
            {
                
                if (!battleHandler.Update())
                {
                    if (battleHandler.Defeat)
                    {
                        gameState = GameState.Death;
                    }
                    else
                    {
                        if (roomNum >= 14)
                        {
                            gameState = GameState.Victory;
                        }
                        else
                        {
                            battleHandler.MapEnemyObject.Active = false;
                            gameState = GameState.Map;
                        }
                    }
                }
            }
            else if (gameState == GameState.Menu)
            {
                prevMS = mouseState;
                mouseState = Mouse.GetState();

                play.Update(mouseState, prevMS);
                settings.Update(mouseState, prevMS);
                if(play.Pressed == true)
                {
                    prevState = gameState;
                    gameState = GameState.Map;
                }
                if(settings.Pressed == true)
                {
                    //Process.Start(@"description.txt");
                    gameState = GameState.Info;
                }
                kbState = Keyboard.GetState();
                if (kbState.IsKeyDown(Keys.Enter))
                {
                    prevState = gameState;
                    gameState = GameState.Map;
                }
            }
            else if(gameState == GameState.Info)
            {
                infoState.Update();

                if (infoState.Exit)
                {
                    gameState = GameState.Menu;
                }
            }
            else if (gameState == GameState.Map)
            {
                #region What it says on the tin

                //replaying the game
                if (prevState == GameState.Menu)
                {
                    prevState = gameState;

                    burrito = new MapEnemy(
                            rgen.Next(20, GraphicsDevice.Viewport.Width - 50),
                            rgen.Next(20, GraphicsDevice.Viewport.Width - 50),
                            "Duergar", "Shade"
                            );
                    burrito.Active = false;

                    roomNum = 0;

                    //battleHandler.ResetHealth();
                    //agroBubble = new Rectangle(GraphicsDevice.Viewport.Width / 4, GraphicsDevice.Viewport.Height / 4, GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2);
                }
                kbState = Keyboard.GetState();
                
                
                if (kbState.IsKeyDown(Keys.B))
                {
                    burrito = new MapEnemy(
                        GraphicsDevice.Viewport.Width / 2,
                        GraphicsDevice.Viewport.Height / 2,
                        "Mind Flayer");

                    //roomNum = 0;
                    agroBubble.X = 0;
                    agroBubble.Y = 0;
                    agroBubble.Width = GraphicsDevice.Viewport.Width;
                    agroBubble.Height = GraphicsDevice.Viewport.Height;
                    gameState = GameState.BossRoom;
                }
            
                
                //setting the agro area
                agroBubble.Width = GraphicsDevice.Viewport.Width;
                agroBubble.Height = GraphicsDevice.Viewport.Height;
                burrito.Agro(player, agroBubble);
                //<quote src=Matt>
                //checking how many rooms player traversed
                if (roomNum >= 15)
                {
                    burrito = new MapEnemy(
                        GraphicsDevice.Viewport.Width / 2,
                        GraphicsDevice.Viewport.Height / 2,
                        "Mind Flayer");
                    
                    //roomNum = 0;
                    agroBubble.X = 0;
                    agroBubble.Y = 0;
                    agroBubble.Width = GraphicsDevice.Viewport.Width;
                    agroBubble.Height = GraphicsDevice.Viewport.Height;
                    gameState = GameState.BossRoom;
                    
                }
                //</quote>

                if (kbState.IsKeyDown(Keys.P) && !kbPrev.IsKeyDown(Keys.P))
                {
                    gameState = GameState.Death;
                }
                player.Update(gameTime, kbState);

                #region handling "doors"
                /*
                //checking the list of doors to see which one player went through

                for (int i = 0; i < doors.Count; i++)
                {
                    //checking if player hits door
                    if (doors[i].Rectangle.Intersects(player.Rectangle))
                    {
                        #region Dooor hit!
                        //Actuallly, not yet.

                        //checking if door is active
                        if (activeDoors.Contains(doors[i]))
                        {
                            #region Now dooor hit!

                            //incrementing room number
                            roomNum++;
                            //checking which door and moving appropriately

                            if (doors[i] == door1)
                            {
                                //clearing active list to create new active list
                                activeDoors.Clear();

                                //adding connecting door and moving player
                                activeDoors.Add(dooorLeft);

                                player.X = GraphicsDevice.Viewport.Width - GraphicsDevice.Viewport.Width / 7 - 40;

                                //spawning enemy in room
                                burrito = MapEnemy.RandomEnemy(GraphicsDevice);

                                burrito.Active = true;

                                //adding random doors
                                int numDoors = rgen.Next(0, 4);
                                int doorToAdd1;
                                int doorToAdd2;
                                int doorToAdd3;

                                switch (numDoors)
                                {
                                    //generating one door
                                    case 1:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 2)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        break;
                                    //generating 2 doors
                                    case 2:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 2)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 2 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        break;
                                    //generating three doors
                                    case 3:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        doorToAdd3 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 2)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 2 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        if (doorToAdd3 != 2 && doorToAdd3 != doorToAdd1 && doorToAdd3 != doorToAdd2)
                                        {
                                            activeDoors.Add(doors[doorToAdd3]);
                                        }
                                        break;
                                }
                            }

                            else if (doors[i] == door2)
                            {
                                //clearing active list to create new active list
                                activeDoors.Clear();

                                //adding connecting door and moving player
                                activeDoors.Add(door4);

                                player.Y =
                                    GraphicsDevice.Viewport.Height
                                    - door2.Rectangle.Height
                                    - player.Rectangle.Height
                                    - 30;

                                //spawning enemy in room
                                burrito = MapEnemy.RandomEnemy(GraphicsDevice);
                                

                                //adding random doors
                                int numDoors = rgen.Next(0, 4);
                                int doorToAdd1;
                                int doorToAdd2;
                                int doorToAdd3;

                                switch (numDoors)
                                {
                                    //generating one door
                                    case 1:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 3)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        break;
                                    //generating two doors
                                    case 2:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 3)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 3 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        break;
                                    //generating three doors
                                    case 3:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        doorToAdd3 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 3)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 3 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        if (doorToAdd3 != 3 && doorToAdd3 != doorToAdd1 && doorToAdd3 != doorToAdd2)
                                        {
                                            activeDoors.Add(doors[doorToAdd3]);
                                        }
                                        break;
                                }
                            }

                            else if (doors[i] == dooorLeft)
                            {
                                //clearing active list to create new active list
                                activeDoors.Clear();

                                //adding connecting door
                                activeDoors.Add(door1);

                                player.X = 40;

                                //spawning new enemy
                                burrito = MapEnemy.RandomEnemy(GraphicsDevice);

                                //adding random doors
                                int numDoors = rgen.Next(0, 4);
                                int doorToAdd1;
                                int doorToAdd2;
                                int doorToAdd3;

                                switch (numDoors)
                                {
                                    //generating one door
                                    case 1:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 0)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        break;
                                    //generating two doors
                                    case 2:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 0)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 0 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        break;
                                    //generating three doors
                                    case 3:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        doorToAdd3 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 0)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 0 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        if (doorToAdd3 != 0 && doorToAdd3 != doorToAdd1 && doorToAdd3 != doorToAdd2)
                                        {
                                            activeDoors.Add(doors[doorToAdd3]);
                                        }
                                        break;
                                }
                            }

                            else if (doors[i] == door4)
                            {
                                //clearing active list to create new active list
                                activeDoors.Clear();

                                //adding connecting door
                                activeDoors.Add(door2);
                                player.Y = 40;

                                //spawning enemy
                                burrito = MapEnemy.RandomEnemy(GraphicsDevice);

                                //adding random doors
                                int numDoors = rgen.Next(0, 4);
                                int doorToAdd1;
                                int doorToAdd2;
                                int doorToAdd3;

                                switch (numDoors)
                                {
                                    //generating one doors
                                    case 1:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 1)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        break;
                                    //two doors
                                    case 2:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 1)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 1 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        break;
                                    //three doors
                                    case 3:
                                        doorToAdd1 = rgen.Next(0, 3);
                                        doorToAdd2 = rgen.Next(0, 3);
                                        doorToAdd3 = rgen.Next(0, 3);
                                        if (doorToAdd1 != 1)
                                        {
                                            activeDoors.Add(doors[doorToAdd1]);
                                        }
                                        if (doorToAdd2 != 1 && doorToAdd2 != doorToAdd1)
                                        {
                                            activeDoors.Add(doors[doorToAdd2]);
                                        }
                                        if (doorToAdd3 != 1 && doorToAdd3 != doorToAdd1 && doorToAdd3 != doorToAdd2)
                                        {
                                            activeDoors.Add(doors[doorToAdd3]);
                                        }
                                        break;
                                }
                            }
                            #endregion
                            break;
                        }
                        #endregion
                    }
                }
                */
                #endregion
                //Wow, Mattt - that's something!
                //Now let me try.

                #region Handling dooors
                //Threee o's
                foreach (Door door in activeDoors)
                {
                    if (door.Rectangle.Intersects(player.Rectangle))
                    {

                        activeDoors.Clear();

                        bool[] dooorsToAddd = new bool[4];

                        for (int i = 0; i < dooorsToAddd.Length; i++)
                        {
                            dooorsToAddd[i] = (rgen.Next(2) == 1);
                        }

                        if (door == dooorRight)
                        {
                            player.X = 50;
                            dooorsToAddd[0] = true;
                        }
                        else if (door == dooorLeft)
                        {
                            player.X = GraphicsDevice.Viewport.Width - player.Rectangle.Width - 50;
                            dooorsToAddd[2] = true;
                        }
                        else if (door == dooorTop)
                        {
                            player.Y = GraphicsDevice.Viewport.Height - player.Rectangle.Height - 50;
                            dooorsToAddd[3] = true;
                        }
                        else if (door == dooorBotttom)
                        {
                            player.Y = 50;
                            dooorsToAddd[1] = true;
                        }

                        for (int i = 0; i < dooorsToAddd.Length; i++)
                        {
                            if (dooorsToAddd[i])
                            {
                                activeDoors.Add(doors[i]);
                            }
                        }

                        burrito = MapEnemy.RandomEnemy(GraphicsDevice);
                        
                        roomNum++;

                        break;
                    }
                }
                #endregion
                SetBounds(player);

                //checking for state change
                if (burrito.CheckCollision(player) == true)
                {
                    battleHandler = new Combat(knight, ranger, mage, burrito);
                    gameState = GameState.Combat;
                }
                kbPrev = kbState;
                #endregion
            }

            else if (gameState == GameState.BossRoom)
                //A proposal: I'lll stop whining about double lettters,
                //and even stop tripling lettters in my commments, if
                //you switch (hahaha) these if statements with a switch.
            {
                burrito.Active = true;
                 

                kbPrev = kbState;
                kbState = Keyboard.GetState();
                burrito.Agro(player, agroBubble);

                SetBounds(player);

                player.Update(gameTime, kbState);

                if (player.Rectangle.Intersects(burrito.Rectangle))
                {
                    battleHandler = new Combat(knight, ranger, mage, burrito);
                    gameState = GameState.Combat;
                }
            }

            else if(gameState == GameState.Death)
            {
                kbState = Keyboard.GetState();
                mouseState = Mouse.GetState();
                if (kbState.IsKeyDown(Keys.Space) && !kbPrev.IsKeyDown(Keys.Space))
                {
                    gameState = GameState.Menu;
                }
                exit.Update(mouseState, prevMS);
                if (exit.Pressed)
                {
                    Exit();
                }
                kbPrev = kbState;
                prevMS = mouseState;
            }
            else if (gameState == GameState.Victory)
            {
                kbState = Keyboard.GetState();
                mouseState = Mouse.GetState();

                if (kbState.IsKeyDown(Keys.Space) && !kbPrev.IsKeyDown(Keys.Space))
                {
                    gameState = GameState.Menu;
                }
                exit.Update(mouseState, prevMS);
                if (exit.Pressed)
                {
                    Exit();
                }
                kbPrev = kbState;
                prevMS = mouseState;

            }

            //player.Update(gameTime, playerDir);
            base.Update(gameTime);

            
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            
            //setting the finite state machine for draw methods        
            if (gameState == GameState.Map)
            {

                
                //will replace colors with background sprites later
                Rectangle rec = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

                spriteBatch.Draw(background, rec, Color.White);

                //drawing player and enemy
                player.Draw(spriteBatch);

                if (burrito.Active)
                {
                    burrito.Draw(spriteBatch);
                }

                for(int i = 0; i < activeDoors.Count; i++)
                {
                    activeDoors[i].Draw(spriteBatch);
                }

                DrawHealthBars();
            }
            else if (gameState == GameState.BossRoom)
            {
                Rectangle rec = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
                spriteBatch.Draw(background, rec, Color.White);
                burrito.Draw(spriteBatch);
                player.Draw(spriteBatch);

                DrawHealthBars();
            }
            else if(gameState == GameState.Menu)
            {
                spriteBatch.Draw(menuBG, menuRec, Color.White);
                spriteBatch.Draw(play.Texture, play.Rectangle, Color.White);
                spriteBatch.Draw(settings.Texture, settings.Rectangle, Color.White);
                spriteBatch.Draw(title2, coolTitle, Color.White);
                //spriteBatch.DrawString(font, "Underdark", title = new Vector2((GraphicsDevice.Viewport.Width/2)-200, (GraphicsDevice.Viewport.Height/3)-100), Color.White,0,Vector2.Zero,5,SpriteEffects.None,0);
                //GraphicsDevice.Clear(Color.Black);
                if(menuRec.X > -640 && menuRec.Y == 0)
                {
                    menuRec.X -= 1;
                }
                else if(menuRec.X == -640 && menuRec.Y > -360)
                {
                    menuRec.Y -= 1;
                }
                else if (menuRec.X < 0 && menuRec.Y == -360)
                {
                    menuRec.X += 1;
                }
                else if (menuRec.X == 0 && menuRec.Y < 0)
                {
                    menuRec.Y += 1;
                }
            }
            else if(gameState == GameState.Info)
            {
                spriteBatch.Draw(menuBG, menuRec, Color.White);
                infoState.Draw(spriteBatch);
                if (menuRec.X > -640 && menuRec.Y == 0)
                {
                    menuRec.X -= 1;
                }
                else if (menuRec.X == -640 && menuRec.Y > -360)
                {
                    menuRec.Y -= 1;
                }
                else if (menuRec.X < 0 && menuRec.Y == -360)
                {
                    menuRec.X += 1;
                }
                else if (menuRec.X == 0 && menuRec.Y < 0)
                {
                    menuRec.Y += 1;
                }
            }
            else if(gameState == GameState.Combat)
            {
                GraphicsDevice.Clear(Color.White);
                Rectangle rec = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

                spriteBatch.Draw(combatBG, rec, Color.White);
                battleHandler.Draw(spriteBatch);
            }
            else if(gameState == GameState.Death)
            {
                spriteBatch.Draw(deathT, deathRec, Color.White);
                spriteBatch.DrawString(font, "Game Over", title = new Vector2((GraphicsDevice.Viewport.Width / 2) - 200, (GraphicsDevice.Viewport.Height / 3) - 200), Color.Black, 0, Vector2.Zero, 4, SpriteEffects.None, 0);
                spriteBatch.Draw(exit.Texture, exit.Rectangle, Color.White);
            }
            else if (gameState == GameState.Victory)
            {
                spriteBatch.Draw(victoryT, victoryRec, Color.White);
                spriteBatch.DrawString(font, "You                           Win", title = new Vector2((GraphicsDevice.Viewport.Width / 2) - 400, (GraphicsDevice.Viewport.Height / 3) - 25), Color.Black, 0, Vector2.Zero, 4, SpriteEffects.None, 0);
                spriteBatch.Draw(exit.Texture, exit.Rectangle, Color.White);
            }
            spriteBatch.End();
            base.Draw(gameTime);
        }

        private void DrawHealthBars()
        {
            spriteBatch.DrawString(font, knight.Name, warrior, Color.Black);


            spriteBatch.DrawString(font, ranger.Name, 
                                        new Vector2(warrior.X + healthbarWidth
                                                              + healthbarGutter,
                                                    warrior.Y),
                                        Color.Black);


            spriteBatch.DrawString(font, mage.Name,
                                        new Vector2(warrior.X + 2*healthbarWidth
                                                              + 2*healthbarGutter,
                                                    warrior.Y),
                                        Color.Black);


            spriteBatch.Draw(Combat.HealthBarSprite, 
                            new Rectangle((int)warrior.X,
                                          (int)warrior.Y + 20,
                                          healthbarWidth * knight.Health / knight.MaxHealth,
                                          25),
                            Color.White);


            spriteBatch.Draw(Combat.HealthBarSprite,
                            new Rectangle((int)warrior.X + healthbarWidth + healthbarGutter,
                                          (int)warrior.Y + 20,
                                          healthbarWidth * ranger.Health / ranger.MaxHealth,
                                          25),
                            Color.White);


            spriteBatch.Draw(Combat.HealthBarSprite,
                            new Rectangle((int)warrior.X + 2*healthbarWidth + 2*healthbarGutter,
                                          (int)warrior.Y + 20,
                                          healthbarWidth * mage.Health / mage.MaxHealth,
                                          25),
                            Color.White);
        }

        public void SetBounds(GameObject player)
        {
            //checking if out of bounds
            //left side of screen
            if (player.X < 0)
            {
                //hitting the wall
                player.X = 0;
            }
            //top of screen
            else if (player.Y < 0)
            {
                //hitting the wall
                player.Y = 0;
            }
            //right side of screen
            else if (player.X > GraphicsDevice.Viewport.Width-GraphicsDevice.Viewport.Width/13)
            {
                //hitting the wall
                player.X = GraphicsDevice.Viewport.Width - GraphicsDevice.Viewport.Width / 13;
            }
            //bottom of screen
            else if (player.Y > GraphicsDevice.Viewport.Height-GraphicsDevice.Viewport.Height/8)
            {
                //hitting the wall
                player.Y = GraphicsDevice.Viewport.Height - GraphicsDevice.Viewport.Height / 8;
            }
        }
    }
}
