﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class BattleObject
    {
        private int speed;
        private int attDmg;
        private int health;
        string side;
        string type;
        bool isAlive;

        public BattleObject(Character player)
        {
            speed = player.Speed;
            attDmg = player.AttackDmg;
            health = player.Health;
            side = "Player";
            type = player.ClassType;
            isAlive = true;
        }

        public BattleObject(Enemy enemy, Rectangle r)
        {
            speed = enemy.Speed;
            attDmg = enemy.AttDam;
            health = enemy.Health;
            side = "Enemy";
        }

        public bool IsAlive
        {
            get { return isAlive; }
            set { isAlive = value; }
        }

        public string Type
        {
            get { return type; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public string Side
        {
            get { return side; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public int AttackDmg
        {
            get { return attDmg; }
            set { attDmg = value; }
        }
    }
}
