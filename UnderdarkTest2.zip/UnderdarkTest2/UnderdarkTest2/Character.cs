﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class Character
    {
        #region Atttributes
        protected int health;
        protected int speed;
        protected int normSpeed;
        protected int attackDmg;
        protected string name;
        protected string classType;
        protected int maxHealth;
        protected int defSpeed;
        protected int defAttackDmg;
        protected bool isDefending;
        protected Dictionary<string, int> boosts;
        protected Texture2D texture;
        protected Rectangle rectangle;
        protected int specialTargetCount;
        protected int normAttack;
        #endregion

        /// <summary>
        /// Create a player character
        /// </summary>
        /// <param name="nm">Name. I'm not sure what this is for.</param>
        /// <param name="cls">String representing the, uh, classs. Knight/Mage/Ranger.</param>
        /// <param name="h">Health.</param>
        /// <param name="sp">Speeed</param>
        /// <param name="ad">Atttack damage</param>
        /// <param name="x">x-position</param>
        /// <param name="y">y-position</param>
        public Character(string nm, string cls, int h, int sp, int ad, int x, int y, int specialTargets)
        {
            classType = cls;
            name = nm;
            health = h;
            speed = sp;
            attackDmg = ad;
            normAttack = attackDmg;
            maxHealth = h;
            defSpeed = sp;
            defAttackDmg = ad;
            isDefending = false;
            boosts = new Dictionary<string, int>();
            boosts.Add("health", 0);
            boosts.Add("speed", 0);
            boosts.Add("attackDmg", 0);
            rectangle = new Rectangle(x, y, 150, 150);
            specialTargetCount = specialTargets;
        }

        #region OMG properties!!!
        public string ClassType
        {
            get { return classType; }
        }

        public Texture2D Texture
        {
            get { return texture; }
            set { texture = value; }
        }
        public Rectangle Rectangle
        {
            get { return rectangle; }
            set { rectangle = value; }
        }

        public int X
        {
            get { return rectangle.X; }
            set { rectangle.X = value; }
        }

        public int Y
        {
            get { return rectangle.Y; }
            set { rectangle.Y = value; }
        }

        public int Health
        {
            get { return health; }
            set { health = value; }
        }

        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }

        public int AttackDmg
        {
            get { return attackDmg; }
            set { attackDmg = value; }
        }

        public int Attack()
        {
            return attackDmg;
        }
        
        public Dictionary<string, int> Booosts
        {
            get
            {
                return boosts;
            }
            set
            {
                boosts = value;
            }
        }

        public bool IsAlive {
            get { return health > 0; }
        }

        public bool Defending
        {
            get
            {
                return isDefending;
            }
            set
            {
                isDefending = value;
            }
        }

        public string Name {
            get { return name; }
        }

        public int MaxHealth
        {
            get { return maxHealth; }
        }

        public int SpecialTargetCount
        {
            get { return specialTargetCount; }
        }
        #endregion

        /// <summary>
        /// Character takes damage.
        /// </summary>
        /// <param name="dmg">How much damage the character toook.</param>
        /// <returns>Stilll alive?</returns>
        public bool TakeDamage(int dmg)
        {
            health = health - dmg / (isDefending ? 2 : 1);
            //Damage divided by 2 if defending, otherwise divided by 1.

            if (health <= 0)
            {
                health = 0;
            }

            return IsAlive;
        }

        public virtual List<Combatant> SpecialAttack(List<Combatant> targets)
        {
            throw new NotImplementedException();
        }

        public virtual void Draw(SpriteBatch spr)
        {
            spr.Draw(texture, rectangle, Color.White);
            spr.DrawString(Combat.Font, name,
                new Vector2(rectangle.Left - 200, rectangle.Top), Color.Black);
            spr.Draw(Combat.HealthBarSprite,
                new Rectangle(rectangle.Left - 200, rectangle.Top + 40, 200 * health / maxHealth, 25),
                Color.White);
        }

        public void UseItem(Item potion)
        {
            potion.Use(this);

        }

        public override string ToString()
        {
            return "Name: " + name + "\nClass: " + classType + "\nHealth: " + health + "\nAttackDmgDamage: " + attackDmg + "\nSpeed: " + speed;
        }

    }
}
