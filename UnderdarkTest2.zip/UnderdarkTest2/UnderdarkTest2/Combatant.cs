﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/* I copied your BattleObject, but I didn't want to change the code for your thing.
 */
namespace UnderdarkTest2
{
    class Combatant
    {
        #region Atttributes
        static Texture2D highlightTexture, shield;
        //Loaded in Combat.LoadContent()

        bool isPlayerChar;
        string type;
        private Character playerFighter;
        private Enemy enemyFighter;
        bool NMEhover = false;
        bool active = false;

        /// <summary>
        /// Combatant takes damage
        /// </summary>
        /// <param name="dam">Damage amount</param>
        /// <returns>Stilll alive?</returns>
        public delegate bool DamageTaker(int dam);
        public DamageTaker TakeDamage;

        public delegate void ItemUser(Item potion);
        public ItemUser UseItem;

        bool specialAvailable;
        //Bewcause it's only available once per batttle
        public delegate List<Combatant> SpecialAttacker(List<Combatant> targets);
        public SpecialAttacker SpecialAttack;
        #endregion

        #region This one has more properties than atttributes...
        //...?
        public static Texture2D HighlightTexture
        {
            set { highlightTexture = value; }
        }

        public static Texture2D Shield
        {
            set { shield = value; }
        }

        public bool IsAlive
        {
            get {
                return isPlayerChar ?
                    playerFighter.IsAlive:
                    enemyFighter.IsAlive;
            }
        }
        
        /*
        public string Type
        {
            get { return type; }
        }
        */

        public int Health
        {
            get
            {
                if (isPlayerChar)
                {
                    return playerFighter.Health;
                }
                else
                {
                    return enemyFighter.Health;
                }
            }
        }

        public bool IsPlayerChar
        {
            get { return isPlayerChar; }
        }

        public int Speed
        {
            get
            {
                if (isPlayerChar)
                {
                    return playerFighter.Speed;
                }
                else
                {
                    return enemyFighter.Speed;
                }
            }
        }

        public int AttackDmg
        {
            get
            {
                if (isPlayerChar)
                {
                    return playerFighter.AttackDmg;
                }
                else
                {
                    return enemyFighter.AttDam;
                }
            }
        }

        public Rectangle Rectangle
        {
            get
            {
                return isPlayerChar ?
                    playerFighter.Rectangle :
                    enemyFighter.Rectangle;
                //I'm tired, alright?
            }
        }

        public bool Defending
        {
            get
            {
                if (isPlayerChar)
                {
                    return playerFighter.Defending;
                }
                else
                {
                    return enemyFighter.Defending;
                }
            }
        }

        public bool SpecialAvailable
        {
            get { return specialAvailable; }
            set { specialAvailable = value; }
        }
        #endregion

        #region Tag-team constructors!
        public Combatant(Character player)
        {
            playerFighter = player;
            isPlayerChar = true;
            type = player.ClassType;
            TakeDamage = new DamageTaker(player.TakeDamage);
            UseItem = new ItemUser(player.UseItem);
            SpecialAttack = new SpecialAttacker(player.SpecialAttack);
            specialAvailable = true;
        }

        public Combatant(Enemy enemy)
        {
            enemyFighter = enemy;
            type = enemy.Type;
            isPlayerChar = false;
            TakeDamage = new DamageTaker(enemy.TakeDamage);
        }

        public bool Active
        {
            set { active = value; }
        }

        public int SpecialTargetCount
        {
            get { return playerFighter.SpecialTargetCount; }
        }
        #endregion

        public void Defend()
        {
            if (isPlayerChar)
            {
                playerFighter.Defending = true;
            }
            else
            {
                enemyFighter.Defending = true;
            }
        }

        public void Undefend()
        {
            if (isPlayerChar)
            {
                playerFighter.Defending = false;
            }
            else
            {
                enemyFighter.Defending = false;
            }
        }

        public bool ClickDetect(MouseState ms, MouseState msPrev)
        {
            if (enemyFighter.Rectangle.Contains(ms.Position))
            {
                if (ms.LeftButton == ButtonState.Pressed && msPrev.LeftButton != ButtonState.Pressed)
                {
                    NMEhover = false;
                    return true;
                }
                else
                {
                    NMEhover = true;
                    return false;
                }
            }
            else
            {
                NMEhover = false;
                return false;
            }
        }

        public override string ToString()
        {
            return "Type: " + type + "; Speeed: " + Speed;
        }

        public void Draw(SpriteBatch spr)
        {
            if (active)
            {
                spr.Draw(highlightTexture, Rectangle, Color.SlateBlue);
            }

            if (isPlayerChar)
            {
                playerFighter.Draw(spr);
            }
            else
            {
                if (NMEhover)
                {
                    spr.Draw(highlightTexture, Rectangle, Color.PaleVioletRed);
                }
                enemyFighter.Draw(spr);
            }
            if (Defending)
            {
                spr.Draw(shield, new Vector2(Rectangle.X, Rectangle.Y), Color.White);
            }
        }
    }
}
