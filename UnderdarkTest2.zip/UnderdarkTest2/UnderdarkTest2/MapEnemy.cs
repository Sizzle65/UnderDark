﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class MapEnemy:GameObject
    {
        //attributes
        bool active;
        public Enemy[] enemies;
        static Texture2D shadeTexture, duergarTexture, mindflayerTexture;
        static Random rgen = new Random();

        //Properties
        public static Texture2D ShadeTexture
        {
            get { return shadeTexture; }
            set { shadeTexture = value; }
        }

        public static Texture2D DuergarTexture
        {
            get { return duergarTexture; }
            set { duergarTexture = value; }
        }

        public static Texture2D MindflayerTexture
        {
            get { return mindflayerTexture; }
            set { mindflayerTexture = value; }
        }



        /// <summary>
        /// Map enemy constructor. give it its position and a list of enemies it contains.
        /// </summary>
        /// <param name="x">Map x-coordinate</param>
        /// <param name="y">Map y-coordinate</param>
        /// <param name="width">Map width</param>
        /// <param name="height">Map height</param>
        /// <param name="what_is_inside">Any number of Enemy names; "Shade", "Duergar" or "Mind Flayer"</param>
        public MapEnemy(int x, int y, params string[] what_is_inside) 
            : base(x, y, 200, 200)
        {
            active = true;
            enemies = new Enemy[what_is_inside.Length];
            for(int i = 0; i < what_is_inside.Length; i++)
            {
                switch (what_is_inside[i])
                {
                    case "Shade":
                        if (i == 0) texture = ShadeTexture;
                        enemies[i] = new EnemyShade(Math.Min(i, 2));
                        break;

                    case "Duergar":
                        if (i == 0) texture = DuergarTexture;
                        enemies[i] = new EnemyDuergar(Math.Min(i, 2));
                        break;

                    case "Mind Flayer":
                        if (what_is_inside.Length > 1)
                        {
                            throw new Exception("Mind Flayer AND something else? No.");
                        }
                        texture = MindflayerTexture;
                        enemies[i] = new Boss();
                        break;

                    default:
                        throw new ArgumentException(
                            "You're tring to create a new MapEnemy that contains " +
                            "an enemy of type " + what_is_inside[i] + ". Did you " +
                            "typo?");
                }
            }
        }



        /// <summary>
        /// Map enemy constructor. give it its position and a list of enemies it contains.
        /// </summary>
        /// <param name="x">Map x-coordinate</param>
        /// <param name="y">Map y-coordinate</param>
        /// <param name="width">Map width</param>
        /// <param name="height">Map height</param>
        /// <param name="what_is_inside">Any number of Enemy names; "Shade", "Duergar" or "Mind Flayer"</param>
        public MapEnemy(int x, int y, List<string> what_is_inside)
            : base(x, y, 100, 100)
        {
            active = true;
            enemies = new Enemy[what_is_inside.Count];
            for (int i = 0; i < what_is_inside.Count; i++)
            {
                switch (what_is_inside[i])
                {
                    case "Shade":
                        if (i == 0) texture = ShadeTexture;
                        enemies[i] = new EnemyShade(Math.Min(i, 2));
                        break;

                    case "Duergar":
                        if (i == 0) texture = DuergarTexture;
                        enemies[i] = new EnemyDuergar(Math.Min(i, 2));
                        break;

                    case "Mind Flayer":
                        if (what_is_inside.Count > 1)
                        {
                            throw new Exception("Mind Flayer AND something else? No.");
                        }
                        texture = MindflayerTexture;
                        enemies[i] = new Boss();
                        break;

                    default:
                        throw new ArgumentException(
                            "You're tring to create a new MapEnemy that contains " +
                            "an enemy of type " + what_is_inside[i] + ". Did you " +
                            "typo?");
                }
            }
        }

        public void Agro(MapPlayer player, Rectangle agroBubble)
        {
            if(active == true)
            {
                //checking if player is in agro radius
                if (player.Rectangle.Intersects(agroBubble))
                {
                    //moving to attack
                    if (player.X > this.X)
                    {
                        this.X += 2; 
                    }
                    if (player.X < this.X)
                    {
                        this.X -= 2;
                    }
                    if (player.Y > this.Y)
                    {
                        this.Y += 2;
                    }
                    if (player.Y < this.Y)
                    {
                        this.Y -= 2;
                    }
                }
            }
        }

        //properties
        public bool Active
        {
            get { return active; }
            set { active = value; }
        }

        public bool CheckCollision(GameObject player)
        {
            //if active check for collision
            if (active == true)
            {
                return base.Rectangle.Intersects(player.Rectangle);
            }
            else
            {
                return false;
            }
        }

        public override void Draw(SpriteBatch spriteBatch)
        {
            //if the collectible is active
            if(active == true)
            {
                spriteBatch.Draw(texture, rectangle, Color.White);
            }
        }

        internal static MapEnemy RandomEnemy(GraphicsDevice graphicsDevice)
        {
            int numEnemies = 1 + rgen.Next(3);

            List<string> enemies = new List<string>();

            for (int i = 0; i < numEnemies; i++)
            {
                
                switch (rgen.Next(2))
                {
                    case 0:
                        enemies.Add("Shade");
                        break;

                    case 1:
                        enemies.Add("Duergar");
                        break;
                }
            }

            MapEnemy result = 
            new MapEnemy(
                rgen.Next(
                    graphicsDevice.Viewport.Width / 3,
                    2 * graphicsDevice.Viewport.Width / 3),
                graphicsDevice.Viewport.Height/2 - 50,

                enemies);

            //result.active = false;
            return result;
        }
    }
}
