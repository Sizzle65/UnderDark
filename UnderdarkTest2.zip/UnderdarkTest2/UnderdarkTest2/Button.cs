﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class Button : GameObject
    {
        private int x;
        private int y;
        private int xOrigin;
        private int yOrigin;
        private bool pressed;


        public Button(Rectangle r, Texture2D t):base(r, t)
        {
            x = r.Width;
            y = r.Height;
            pressed = false;
            xOrigin = r.X;
            yOrigin = r.Y;
            
        }

        public bool Pressed
        {
            get { return pressed; }
            set { pressed = value; }
        }
        
        public void Update(MouseState mouseState, MouseState prev)
        {
            if (rectangle.Contains(mouseState.X, mouseState.Y))
            {
                if(rectangle.Width == x)
                {
                    rectangle.Width += 30;
                    rectangle.Height += 30;
                    rectangle.X -= 15;
                    rectangle.Y -= 15;
                }
                
                if (mouseState.LeftButton == ButtonState.Pressed && prev.LeftButton != ButtonState.Pressed)
                {
                    pressed = true;
                }
                else
                {
                    pressed = false;
                }
            }
            else
            {
                rectangle.Width = x;
                rectangle.Height = y;
                rectangle.X = xOrigin;
                rectangle.Y = yOrigin;
                pressed = false;
            }
        }

        public void Update(MouseState mouseState)
        {
            if (rectangle.Contains(mouseState.X, mouseState.Y))
            {
                if (rectangle.Width == x)
                {
                    rectangle.Width += 30;
                    rectangle.Height += 30;
                    rectangle.X -= 15;
                    rectangle.Y -= 15;
                }

                if (mouseState.LeftButton == ButtonState.Pressed)
                {
                    pressed = true;
                }
                else
                {
                    pressed = false;
                }
            }
            else
            {
                rectangle.Width = x;
                rectangle.Height = y;
                rectangle.X = xOrigin;
                rectangle.Y = yOrigin;
                pressed = false;
            }
        }
    }
}
