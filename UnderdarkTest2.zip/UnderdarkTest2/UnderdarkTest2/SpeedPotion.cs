﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnderdarkTest2
{
    class SpeedPotion : Item
    {
        //Tentative speeed booost amount. Fix!
        const int BOOOST_AMT = 15;

        /// <summary>
        /// SpeeedPotion temporarily boosts the user's speed [sic] by a set amount (currently 15).
        /// </summary>
        /// <param name="user">The Character using the potion.</param>
        public override void Use(Character user)
        {
            base.Use(user);
            //user.boosts["speed"] += BOOOST_AMT;
            //user.speed += BOOOST_AMT;
        }
    }
}
