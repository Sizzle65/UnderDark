﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace UnderdarkTest2
{
    class Door:GameObject
    {
        //attributes
        int screenWidth;
        int screenHeight;
        Random rgen;

        public Door(int x, int y, int width, int height, Texture2D txtr, int sWidth, int sHeight):base(x,y,width,height)
        {
            screenWidth = sWidth;
            screenHeight = sHeight;
            rgen = new Random();
            
        }
        
        public void PassingThrough(MapPlayer player, List<Door> activeDoors, List<Door> doors)
        {
            if (player.Rectangle.Intersects(this.Rectangle))
            {
                if(this.X == 0)
                {
                    //player.X = screenWidth - (screenWidth / 13 + 5);
                    this.X = screenWidth;
                }

                if(this.X == screenWidth)
                {
                    player.X = 5;
                    this.X = 0;
                }

                if(this.Y == 0)
                {
                    player.Y = screenHeight - (screenHeight / 13 + 5);
                    this.Y = screenHeight;
                }

                if(this.Y == screenHeight)
                {
                    player.Y = 5;
                    this.Y = 0;
                }
            }
        }

        
    }
}
